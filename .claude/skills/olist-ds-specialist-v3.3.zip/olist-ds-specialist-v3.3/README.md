# Olist Design System — Especialista (v3.3)

Skill corporativa para criação de telas, componentes e protótipos a partir de SDDs/PRDs usando o design system da Olist.

## Novidades v3.3 (2026-06-23)

- Arquivos da skill modificados: README.md
- Decisões de design atualizadas: decisions/CHANGELOG.md
- Outros arquivos: claude/decisions/INDEX.md

## Novidades v3.2 (2026-06-15)

- **UX Writing:** `UX_WRITING.md` adicionado como referência de copy e tom de voz (fonte: skill CX Writing v2.0)
- Novo ramo no Fluxo de Decisão para "Criar ou revisar textos de UI"
- Seção 10 adicionada ao `CHECKLIST_REVISAO.md` com 18 itens de revisão de UX Writing
- Regra crítica 5 no `SKILL.md`: consultar `UX_WRITING.md` ao criar qualquer texto na UI
- `VISAO_GERAL.md` atualizado: 15 referências, nova entrada `UX_WRITING.md`, novo bloco de leitura para copy/UX Writing
- Protocolo de triagem obrigatório: componente → contexto → objetivo antes de qualquer copy
- 4 Pilares de Conteúdo como critério de validação (Conciso, Claro, Significativo, Dialógico)
- 12 tipos de texto mapeados com regras DO/DON'T, limites de caracteres e tokens visuais
- Diretrizes B2B (lojista) vs. B2C (consumidor) com linguagem e tom distintos
- Iniciativa de abrasileiramento documentada (sem hífen, termos técnicos contextualizados, sem termos internos externamente)
- Nomenclatura de produtos Olist (primeira menção + menções posteriores)
- Mapeamento SDD → tipo de texto para tradução de requisitos em copy
- `SKILL.md` atualizado para v3.2

## Novidades v3.1 (2026-06-05)

### Harness de construção de telas (`HARNESS_TELAS.md`):
- Gate pré-construção obrigatório antes de qualquer frame no Figma
- Restrições binárias por zona (A–E) para ERP e Envios/Hub/Conta Digital
- Limites quantitativos por componente (ex: máx 1 `Button` primary por tela)
- Contextos válidos e proibidos por componente
- Harness de primitivos (o que pode e não pode ser construído do zero)
- Padrão de nomenclatura de layers obrigatório
- Estados mínimos obrigatórios por padrão de página
- Formato padronizado para reportar conflitos com o harness

## Novidades v3.0 (2026-06-03)

### Workflow use_figma (canal único de entrega):
- Telas construídas diretamente no Figma via `use_figma` MCP com instâncias reais de componentes DS
- `search_design_system` com `includeLibraryKeys` filtra às 5 libraries autorizadas
- `importComponentSetByKeyAsync` traz componentes reais (Menu ERP, Button, Tags, etc.)
- Workflow faseado: tela por tela com screenshot + feedback a cada entrega

### Libraries como fonte da verdade:
- `figma-config.json` agora usa `libraryKey` (formato `lk-...`) em vez de `fileKey`
- AI Components é o novo master — Menu ERP atualizado + ícones rebrand 24
- 5 libraries em ordem de prioridade; 3 libraries bloqueadas
- `search_design_system` sempre filtrado por `searchPriority`

### Regras da Figma Plugin API documentadas:
- `layoutSizing` definido após `appendChild`
- Valores válidos de `counterAxisAlignItems`: MIN MAX CENTER BASELINE
- Textos em cards: `textAutoResize='HEIGHT'` + `layoutSizingHorizontal='FILL'`

## Estrutura

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist-v3.3/
├── CHANGELOG.md               # Histórico de versões da skill
├── README.md                  # Este arquivo — visão geral e changelog
├── SETUP.md                   # Guia de instalação e configuração
├── SKILL.md                   # Instruções, workflow, regras e fluxo de decisão
├── component-registry.json    # Cache local de componentKeys por categoria
├── figma-config.json          # Libraries autorizadas (libraryKeys e searchPriority)
└── references/
    ├── CHECKLIST_REVISAO.md            # 10 categorias de revisão visual, acessibilidade e UX Writing
    ├── COMPONENTES.md                  # Props e variantes de cada componente (auto-gerado)
    ├── CORES.md                        # Sistema de cores com regras de uso
    ├── ESPACAMENTO.md                  # Grid de 4px, border-radius, escala de espaçamento
    ├── FIGMA_CONFIG.md                 # libraryKeys, workflow de busca e import
    ├── GLOSSARIO_PAPEIS_TEXTO.md       # 10 papéis de texto (Heading, Label, Error, etc.)
    ├── HARNEES_TELAS.md                # Gate pré-construção: restrições por zona, limites por componente
    ├── MAPA_FONTES.md                  # Estrutura de pastas do repositório (auto-gerado)
    ├── PADROES.md                      # 5 padrões de página (Tabela, Form, Dashboard, Detalhe, Config)
    ├── SDD_AVANCADO.md                 # RNFs, DACI, Métricas, Rollout, Observabilidade → UI
    ├── SDD_PARA_TELA.md                # 10 passos para traduzir SDD/PRD em decisões de UI
    ├── TEMPLATES_PRODUTO.md            # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── TIPOGRAFIA.md                   # Tokens de tipografia (tamanho, peso, altura)
    ├── UX_WRITING.md                   # Tom de voz, 4 pilares, 12 tipos de texto, diretrizes B2B/B2C
    └── VISAO_GERAL.md                  # Mapa de navegação — leia sempre primeiro
```

> **Raiz:** 6 arquivo(s) · **Referências:** 15 arquivo(s) · **Total:** 21 arquivo(s) — atualizado automaticamente pelo `sync-skill-meta.mjs`

```
olist-ds-specialist/
├── SKILL.md                           # Instruções, workflow, regras v3.1
├── README.md                          # Este arquivo
├── SETUP.md                           # Guia de instalação
├── figma-config.json                  # Libraries autorizadas (libraryKeys)
└── references/
    ├── VISAO_GERAL.md                 # Mapa de navegação
    ├── FIGMA_CONFIG.md                # libraryKeys, workflow de busca e import
    ├── TEMPLATES_PRODUTO.md           # Zonas de layout por produto (ERP, Envios, Hub, CD)
    ├── HARNESS_TELAS.md               # Restrições executáveis de construção de telas ← novo
    ├── CORES.md                       # Sistema de cores
    ├── TIPOGRAFIA.md                  # Tokens de tipografia
    ├── GLOSSARIO_PAPEIS_TEXTO.md      # 10 papéis de texto
    ├── ESPACAMENTO.md                 # Grid, border-radius
    ├── COMPONENTES.md                 # Props e variantes (auto-gerado)
    ├── PADROES.md                     # Padrões de página
    ├── MAPA_FONTES.md                 # Estrutura de pastas (auto-gerado)
    ├── SDD_PARA_TELA.md               # 10 passos SDD → UI
    ├── SDD_AVANCADO.md                # RNFs, DACI, Métricas
    └── CHECKLIST_REVISAO.md           # 9 categorias de revisão
```

## Libraries do Figma (ordem de prioridade)

| # | Library | Conteúdo |
|---|---|---|
| 1 (master) | **AI Components** | Menu ERP atualizado, Button, ícones rebrand 24 |
| 2 | **ERP components** | Componentes principais do ERP Tiny |
| 3 | **ERP recursos** | Recursos e padrões complementares |
| 4 | **ERP style guide** | Tipografia, tokens, paleta |
| 5 (fallback) | **[design system] components web** | Componentes web base |

**libraryKeys completas:** ver `figma-config.json`.

## Instalação

### Opção 1: Script automático
```bash
unzip olist-ds-kit.zip && cd olist-ds-kit && bash setup.sh
```

### Opção 2: Claude Code
```bash
mkdir -p .claude/skills
cp -r olist-ds-specialist/ .claude/skills/olist-ds-specialist/
```

### Opção 3: Claude.ai
Settings → Customize → Skills → Upload pasta.

## Uso

### Criar tela no Figma (workflow principal)
```
Use $olist-ds-specialist para criar UI no Figma:
[SDD aqui]
```
Claude executa o gate do harness → busca componentes nas libraries autorizadas → importa instâncias reais → constrói via `use_figma` → retorna screenshot + link.

### Criar tela React
```
Use $olist-ds-specialist para criar a tela deste SDD:
[SDD aqui]
```

### Revisar UI existente
```
Use $olist-ds-specialist para revisar esta tela:
[código ou screenshot]
```

### Sincronizar inventário de componentes
```
Sincronize o registry de componentes
```

## Changelog

### v3.3 (2026-06-23)
- Arquivos da skill modificados: README.md
- Decisões de design atualizadas: decisions/CHANGELOG.md
- Outros arquivos: claude/decisions/INDEX.md

### v3.2 (2026-06-15)
- **UX Writing:** `UX_WRITING.md` adicionado como referência de copy e tom de voz (fonte: skill CX Writing v2.0)
- Novo ramo no Fluxo de Decisão para "Criar ou revisar textos de UI"
- Seção 10 adicionada ao `CHECKLIST_REVISAO.md` com 18 itens de revisão de UX Writing
- Regra crítica 5 no `SKILL.md`: consultar `UX_WRITING.md` ao criar qualquer texto na UI
- `VISAO_GERAL.md` atualizado: 15 referências, nova entrada `UX_WRITING.md`, novo bloco de leitura para copy/UX Writing
- Protocolo de triagem obrigatório: componente → contexto → objetivo antes de qualquer copy
- 4 Pilares de Conteúdo como critério de validação (Conciso, Claro, Significativo, Dialógico)
- 12 tipos de texto mapeados com regras DO/DON'T, limites de caracteres e tokens visuais
- Diretrizes B2B (lojista) vs. B2C (consumidor) com linguagem e tom distintos
- Iniciativa de abrasileiramento documentada (sem hífen, termos técnicos contextualizados, sem termos internos externamente)
- Nomenclatura de produtos Olist (primeira menção + menções posteriores)
- Mapeamento SDD → tipo de texto para tradução de requisitos em copy
- `SKILL.md` atualizado para v3.2

### v3.1 (2026-06-05)
- **Harness:** `HARNESS_TELAS.md` adicionado como gate pré-construção obrigatório no Figma
- Gate com 6 itens binários executados antes de qualquer frame
- Restrições de zona, componente, primitivo, nomenclatura e estados por padrão de página
- 14 arquivos de referência ativos

### v3.0 (2026-06-03)
- **Canal de entrega:** `use_figma` direto com instâncias DS reais (plugin intermediário descontinuado)
- **Libraries:** `figma-config.json` migrado de `fileKey` para `libraryKey`; AI Components como master
- **Busca:** `search_design_system` sempre com `includeLibraryKeys: searchPriority`
- **Regras Figma Plugin API:** documentadas em SKILL.md (layoutSizing, counterAxisAlignItems, etc.)
- Removido: `screen-spec-schema.json`, plugin Screen Builder, modo JSON econômico
- 13 arquivos de referência ativos

### v2.2 (2026-06-03)
- Modo JSON para plugin Figma (econômico)
- component-registry.json, screen-spec-schema.json
- TEMPLATES_PRODUTO.md (zonas de layout por produto)

### v2.1 (2026-05-19)
- FIGMA_CONFIG.md, SETUP.md

### v2.0 (2026-05-04)
- GLOSSARIO_PAPEIS_TEXTO.md, SDD_AVANCADO.md
- Workflow faseado no Figma

### v1.0 (2026-01-12)
- Release inicial
