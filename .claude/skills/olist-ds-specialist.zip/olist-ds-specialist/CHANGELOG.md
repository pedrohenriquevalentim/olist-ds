## v3.22 (2026-09-25) — 2ª rodada

### component-registry.json + figma-config.json + globals.md — 2ª rodada de /ds-sync

**Arquivos modificados:** `component-registry.json`, `figma-config.json`, `globals.md`

#### Fixed

- **Drawer componentKey:** era `null` — resolvido para `f466ce17b00d813e1a9e48fdbf4030980371e6c5`.

#### Added

- **Loading** adicionado ao registry (key `0d32737ae3b73820a283a1453b7e85d9ffa5c669`, category: feedback) — estava no inventário do `globals.md` mas sem entry no registry.
- **Chart Bar Up / Bar Down / Bar Variation / Chart Pie** adicionados ao registry com seus componentKeys (category: data-visualization) — estavam no inventário mas sem componentKeys.
- **Update** (ícone individual, key `d6a0734de0d76ea39dd0adfc3e0a356e900bf663`) adicionado ao registry.
- **File Pie Chart** (ícone individual, key `39806c4ceeffa09ff8a020b656cfb528e60d6005`) adicionado ao registry.
- `totalComponents` atualizado: 63 → 71.

#### Gaps identificados

- **Modal** — busca `modal` retornou `card` mas não um component_set `modal`. Ainda WIP, componentKey: null.
- **Overlay** — não retornou em busca direta; pode ser sinônimo do Drawer ou não publicado.
- **Menu** (key `4a05e281...`) — variantsConfirmed: false, aguarda URL do Figma.

---

## v3.22 (2026-09-25)

### globals.md + HARNEES_TELAS.md — correção de 4 regressões reportadas por designers

**Arquivos modificados:** `globals.md`, `references/HARNEES_TELAS.md`

#### Fixed

- **Library não subscrita (warning falso positivo):** o agente exibia o aviso "Library não subscrita" ao usuário antes de tentar a subscrição automática. A regra correta é executar silenciosamente o sentinel import (Seção 0, Passo 3 do HARNEES_TELAS.md) e só reportar erro se o próprio import falhar. Adicionado em `globals.md` (Nunca) e `HARNEES_TELAS.md` (Seção 0).
- **Spacer frames:** o agente criava frames vazios para adicionar espaçamento entre elementos em vez de usar `itemSpacing` (gap). Adicionada proibição explícita em `globals.md` (Figma Plugin API table + Nunca) e `HARNEES_TELAS.md` (Seções 1 e 4).
- **`clipsContent: true`:** a regra `clipsContent: false` existia apenas para "frames de zona ERP". Elevada para regra universal (todo frame, sem exceção) em `globals.md` e `HARNEES_TELAS.md`.
- **Fills hardcoded em elementos primários:** a regra de `importVariableByKeyAsync` + `setBoundVariableForPaint` estava limitada a "componentes custom". Estendida para qualquer frame ou primitivo — backgrounds de zonas, containers de layout, cards. Corrigido em `globals.md` e `HARNEES_TELAS.md` Seção 4.

---

## v3.21 (2026-09-20)

### Dispatcher + globals.md + cases/ — redução de 65–75% nos tokens por invocação

**Arquivos modificados:** `SKILL.md`  
**Arquivos criados:** `globals.md`, `cases/caso-1-2-tela-react.md`, `cases/caso-3-revisar.md`, `cases/caso-4-figma.md`, `cases/caso-5-construir.md`, `cases/caso-6-sync.md`, `cases/caso-7-componente.md`, `cases/caso-8-implementar.md`, `cases/caso-9-handoff.md`  
**Sub-skills atualizadas:** `ds-tela`, `ds-componente`, `ds-figma`, `ds-revisar`, `ds-sync`, `ds-handoff`, `ds-implementar`, `ds-construir`

#### Motivação

O `SKILL.md` original (726 linhas, 53 KB) era carregado integralmente em toda invocação de qualquer sub-skill. Um `/ds-tela` carregava as instruções do Caso 7, as regras do Caso 5, a tabela de Figma Plugin API e o changelog completo — nenhum deles relevante para gerar uma tela React. Cada invocação consumia ~746 linhas de contexto para usar no máximo 15% delas.

#### Changed

- **`SKILL.md`** reescrito como dispatcher puro (75 linhas): tabela de slash commands, fluxo de decisão, tabela de roteamento caso → arquivo, instrução de carregamento (`globals.md` + `cases/caso-N.md`). Sem conteúdo de caso inline.
- **8 sub-skills** (`ds-*/SKILL.md`): substituem `ler SKILL.md principal` por `ler globals.md` + `ler cases/caso-N.md`.

#### Added

- **`globals.md`** (123 linhas): invariantes compartilhados — papel/escopo, regras de library Figma (`searchPriority`, `blockedLibraries`, filtro `.[base]`), inventário de componentes compacto, URL do COMPONENTES.md no GitHub, tabela de arquivos de referência, tabela de erros da Figma Plugin API, regras críticas do/don't.
- **`cases/`** (8 arquivos, 428 linhas total): cada arquivo contém apenas os passos do caso correspondente — extração direta do SKILL.md anterior sem perda de conteúdo.

#### Ganho por invocação (linhas carregadas)

| Sub-skill | Antes | Depois | Redução |
|---|---|---|---|
| `/ds-tela` | 746 | 195 | 74% |
| `/ds-figma` | 746 | 190 | 75% |
| `/ds-componente` | 746 | 227 | 70% |
| `/ds-construir` | 746 | 258 | 65% |
| `olist-ds-specialist` (auto) | 726 | 314 (pior caso) | 57% |

---

## v3.20 (2026-09-09)

### Protocolo de Inicialização de Arquivo + Cover Rebrand Olist + Skill auto-contida para Caso 7

**Arquivos modificados:** `SKILL.md`, `references/HARNEES_TELAS.md`, `references/FIGMA_CONFIG.md`  
**Arquivo criado:** `references/METADATA_SCHEMA.md`

#### Added
- **Seção 0 — Protocolo de Inicialização de Arquivo** em `HARNEES_TELAS.md` (v1.6 → v2.0): 4 passos obrigatórios antes de qualquer frame — `create_new_file`, configuração das 3 páginas padrão, import de sentinels (Button + variável semântica), verificação via `get_libraries` + `get_variable_defs`
- **Layout oficial do cover** (referência `HeyN4w209HWh8rfpTDiwyf` node `10942:33207`): 1920×960px, fundo `#f2f0e8`, 5 campos dinâmicos com resolução automática — `{NOME DO USUÁRIO}` (primeiro nome do operador, CAIXA ALTA), `{nome do projeto}` (title case, máx 45 chars), `{unidade de negócio}` (detectado do contexto), `{status}` (default "Em exploração"), `{ano atual}` (YYYY). Pill "DESIGN TEAM" verde `#779e3d`, pill do designer dark navy `#001647` em x=590 y=150
- **`references/METADATA_SCHEMA.md`** (novo): schema completo do `NomeComponente.metadata.json` para o Caso 7 (`/ds-componente`) — elimina dependência do `CLAUDE.md` raiz do repositório `olist-ds`; skill passa a ser auto-contida para geração de componentes
- **Gate Obrigatório item [0]** em `HARNEES_TELAS.md`: "Protocolo de Inicialização (Seção 0) concluído — arquivo criado, páginas configuradas, sentinel importado, `get_libraries` e `get_variable_defs` passando?" — **BLOQUEANTE**
- **`FIGMA_CONFIG.md`** checklist: 2 novos itens — validação de `libraryKey` via `get_libraries` e confirmação de `get_variable_defs` pós-sentinel
- **`SKILL.md`** "Sempre Faça" item 14: executar Protocolo de Inicialização antes de qualquer `use_figma`
- **`SKILL.md`** "Nunca Faça" item 19: criar frames sem protocolo de inicialização concluído
- **`SKILL.md`** Caso 5 PRÉ-FLIGHT: `get_variable_defs` no arquivo DS confirma 3 coleções antes de criar tokens

#### Changed
- **Caso 4**: passo 8 (inicialização) adicionado; passos renumerados 9–11; fallback distingue "library inacessível" (PARAR) de "componente genuinamente ausente" (usar primitivos)
- **Caso 7** referência de schema: `CLAUDE.md` raiz → `references/METADATA_SCHEMA.md` + `decisions/technical/COMPONENTES_REACT.md`
- **`HARNEES_TELAS.md`** Passo 2 reescrito com spec visual completa do cover: tabela de campos dinâmicos, tabela de elementos, implementação com caminho primário (componente DS real) + fallback (primitivos com spec exata)

#### Fixed
- **Gap crítico silencioso 1**: `importComponentByKeyAsync` falhava sem erro em arquivos novos/sem library subscrita — resolvido por sentinel obrigatório no Passo 3 da Seção 0
- **Gap crítico silencioso 2**: `get_variable_defs` retornava vazio em arquivos novos, resultando em fills hardcoded em vez de tokens DS — resolvido pela verificação bloqueante no Passo 4

---

## v3.19 (2026-08-29)

### Convenções de layout ERP — definidas e registradas

**Arquivos modificados:** `references/TEMPLATES_PRODUTO.md`, `component-registry.json`, `SKILL.md`

#### Added
- **Frame raiz:** `padding 8px` em todos os lados + `fills #F1F0E8` + `gap 8px` entre Zona A e Container
- **Container (Zonas B–F):** `cornerRadius 12px`
- **Zona B:** `topLeftRadius 12` · `topRightRadius 12` · bottom 0
- **Zona F:** `bottomLeftRadius 12` · `bottomRightRadius 12` · top 0
- **`TableCellExtended`** adicionado ao `component-registry.json` — componentKey `8ba1fe2c9d32e56a058c3946e17142223784c557`, variantes `role × type`, props `header text#10193:5` e `cell text#10193:6`, dimensões confirmadas, usage pattern documentado
- **Regras 11–18** adicionadas ao "Nunca Faça" do `SKILL.md`: clipsContent em zonas (11), strokes em zonas (12), button big/medium em B e C (13), label visível no input search (14), menu erp stage=* (15), tabela com primitivos (16), omitir padding 8px (17), #fcfbf8 no frame raiz (18)

#### Changed
- **`menu-global`** no registry: `note` e `erpLayoutRule` atualizados com regra `Produto=ERP` obrigatória na Zona A e resize correto (304×752px)
- **`Table`** no registry: `note` reescrita — proíbe instanciação direta; redireciona para `TableCellExtended`; marca `head` e `simple cell` como sub-peças internas
- **`TEMPLATES_PRODUTO.md`:** tabela de Zonas ERP, bloco "Regras ERP" e JSON de Estrutura de Layout atualizados com padding, gap, fills, cornerRadius por zona e TableCellExtended
- **Botões nas Zonas B e C:** `size=small` definido como padrão obrigatório
- **Zona E sem Zona F:** recebe `bottomLeftRadius: 12` e `bottomRightRadius: 12`

#### Fixed
- Referência a `"menu erp"` removida do JSON de Estrutura de Layout → substituída por `"menu-global"` com componentKey e `Produto=ERP`
- `clipsContent: false` e `strokes: []` definidos como obrigatórios em todas as zonas (explicitados no checklist)

---

## v3.18 (2026-08-25)
- Arquivos da skill modificados: README.md, SKILL.md, component-registry.json, decisions/INDEX.md, decisions/ux-design/COMPONENTES_POR_ZONA.md, decisions/ux-design/ESPACAMENTO_LAYOUT.md, figma-config.json, references/COMPONENTES.md, references/HARNEES_TELAS.md, references/MAPA_FONTES.md, references/TEMPLATES_PRODUTO.md

## v3.17 (2026-08-23)
- **TOKEN_CATALOG.md criado:** catálogo completo de 1.194 tokens CSS com valores e Figma RGB 0–1 para uso direto na Plugin API. Deve ser regenerado com `npm run sync:skill` quando o CSS mudar.
- **component-registry.json:** 55 de 64 componentes com `variantsConfirmed: true` (antes: 17). Todas as propriedades Figma confirmadas via `get_metadata` com 25 URLs de página. Dois novos componentes adicionados: Drawer e Modal (WIP).
- **CORES.md reescrito:** nomes primitivos corrigidos (`--color-gray-gray-0`, não `--color-gray-0`); tokens semânticos (`--color-background-*`, `--color-text-*`, `--color-border-*`, `--color-shape-*`) adicionados como seção principal; nova seção "Uso em Figma Plugin API" com sintaxe correta de fills (RGB 0–1).
- **TOKENS.md (decisions/technical) reescrito:** hierarquia 3 camadas (Primitivo → Semântico → Componente), tabela "com repo vs sem repo", nomes corretos vs incorretos.
- **Correções de token em 6 arquivos:** `--font-weight-semibold` → `--font-weight-600` (alias não existe no CSS); cores primitivas corrigidas para nomes reais.
- **HARNEES_TELAS.md:** sintaxe Figma Plugin API documentada para fills, strokes e loadFontAsync.

## v3.16 (2026-08-22)
- **Caso 5 (`/ds-construir`):** novo caso de uso e slash command para criar ou evoluir componentes no Figma com arquitetura correta de tokens. Fluxo token-first: auditoria via `get_variable_defs`, decision tree base→theme→component, Gate 1 (plano de tokens para aprovação), construção com Auto Layout e bind de variáveis, Gate 2 (screenshot). Suporta modo NOVO (intenção textual) e modo EVOLUÇÃO (URL Figma). Termina no Figma — não gera código React.
- Pasta `.claude/skills/ds-construir/` criada com `SKILL.md` wrapper delegando ao Caso 5
- Caso 4 atualizado: nota de fallback no passo 9 referencia `/ds-construir` quando componente não existe no inventário
- Fluxo de Decisão e tabela de Slash Commands atualizados com `/ds-construir`

## v3.15 (2026-08-19)
- **Caso 7 (`/ds-componente`):** passa a gerar `NomeComponente.metadata.json` como sexto arquivo obrigatório (purpose/useWhen/doNotUseWhen/pairsWith/note/variants/states/slots/tokens/figma), com gate obrigatório de aprovação do usuário antes de código e docs
- Campo `componentKey` adicionado ao bloco `figma` do schema de metadata (identificador do componente publicado na library, diferente de `fileKey`/`nodeId`)
- `CLAUDE.md` raiz atualizado: seção "Estrutura de Cada Componente" e seção 9 "Saída Esperada"
- Regras críticas 13 ("Sempre Faça") e 10 ("Nunca Faça") adicionadas
- 10 componentes retroativos atualizados com `fileKey`/`componentKey` reais de `component-registry.json`

## v3.14 (2026-07-20)
- `/ds-sync`: inventário de componentes ressincronizado com a `design system (base)` — famílias Tabela, Gráfico (nova categoria "Data Visualization"), `Paginator`, `Badge`, `Sort`, `Reorder`, `Loading`, `Overlay`, `Cookie`, `Logout`, `Profile`, `Dashboard`, `List`, `Task List`, `Avatar`, `Card`
- "Text Area" renomeado para "Input Paragraph" (mesmo componente, nome real confirmado no Figma)
- Gap do `Paginator`/`Overlay` marcado como resolvido em `GOVERNANCA_TOKENS.md` — componentes já existem na library

## v3.13 (2026-07-04)
- Sincronização de versão (sem mudanças funcionais documentadas)

## v3.12 (2026-07-04)
- Sincronização de versão (sem mudanças funcionais documentadas)

## v3.11 (2026-07-04)
- Sincronização de versão (sem mudanças funcionais documentadas)

## v3.10 (2026-07-02)
- Sincronização de versão (sem mudanças funcionais documentadas)

## v3.9 (2026-07-02)
- Sincronização de versão (sem mudanças funcionais documentadas)

## v3.8 (2026-06-29)
- **Slash Commands:** 6 skills finas criadas em `.claude/skills/ds-*/` — `/ds-implementar`, `/ds-tela`, `/ds-figma`, `/ds-componente`, `/ds-revisar`, `/ds-sync` — cada uma delega ao caso correspondente da skill principal
- **Caso 8 (`/ds-implementar`):** novo fluxo para devs de BU converterem telas Figma em JSX tipado usando componentes DS, sem precisar conhecer o inventário de memória
- **Fluxo de Decisão:** roteamento explícito por slash command adicionado antes da detecção automática de intenção
- **`generate-wiki.mjs`:** seção "Como Usar" atualizada com tabela de slash commands
- **`package.json`:** `ship` corrigido para incluir `.storybook/`, `README.md` e `package.json` no `git add` _(npm run ship foi removido posteriormente; fluxo migrado para npm run release)_

## v3.7 (2026-06-25)
- **Fluxo unificado Figma → código + docs:** Caso 7 adicionado ao `SKILL.md` — implementação de componente a partir de URL do Figma executa em paralelo geração de código (5 arquivos — agora 6 desde v3.15, que adicionou metadata.json) e geração de frame de docs no Figma (demo · props · anatomia · acessibilidade)
- `CLAUDE.md` atualizado: passo 10 na seção "Geração de Componentes" e nota de redirecionamento para `olist-ds-specialist` Caso 7
- `decisions/technical/COMPONENTES_REACT.md` atualizado: seção "Documentação no Figma" adicionada
- Ramo "Criar componente" no Fluxo de Decisão expandido para cobrir o fluxo unificado

## v3.6 (2026-06-23)
- Arquivos da skill modificados: SKILL.md, CHANGELOG.md, README.md, SETUP.md, component-registry.json, decisions/CHANGELOG.md, decisions/INDEX.md, decisions/technical/ACESSIBILIDADE.md, decisions/technical/ASSETS_FIGMA.md, decisions/technical/COMPONENTES_REACT.md, decisions/technical/ICONES.md, decisions/technical/TOKENS.md, decisions/ux-design/ESPACAMENTO_LAYOUT.md, decisions/ux-design/FLUXO_PRD_FIGMA.md, decisions/ux-design/PRINCIPIOS.md, decisions/ux-design/TIPOGRAFIA.md, decisions/ux-design/UX_WRITING.md, figma-config.json, references/CHECKLIST_REVISAO.md, references/COMPONENTES.md, references/CORES.md, references/ESPACAMENTO.md, references/FIGMA_CONFIG.md, references/GLOSSARIO_PAPEIS_TEXTO.md, references/HARNEES_TELAS.md, references/MAPA_FONTES.md, references/PADROES.md, references/SDD_AVANCADO.md, references/SDD_PARA_TELA.md, references/TEMPLATES_PRODUTO.md, references/TIPOGRAFIA.md, references/UX_WRITING.md, references/VISAO_GERAL.md
- Outros arquivos: claude/skills/olist-ds-specialist/CHANGELOG.md

## v3.5 (2026-06-23)
- Arquivos da skill modificados: CHANGELOG.md, README.md, SETUP.md, SKILL.md, component-registry.json, decisions/CHANGELOG.md, decisions/INDEX.md, decisions/technical/ACESSIBILIDADE.md, decisions/technical/ASSETS_FIGMA.md, decisions/technical/COMPONENTES_REACT.md, decisions/technical/ICONES.md, decisions/technical/TOKENS.md, decisions/ux-design/ESPACAMENTO_LAYOUT.md, decisions/ux-design/FLUXO_PRD_FIGMA.md, decisions/ux-design/PRINCIPIOS.md, decisions/ux-design/TIPOGRAFIA.md, decisions/ux-design/UX_WRITING.md, figma-config.json, references/CHECKLIST_REVISAO.md, references/COMPONENTES.md, references/CORES.md, references/ESPACAMENTO.md, references/FIGMA_CONFIG.md, references/GLOSSARIO_PAPEIS_TEXTO.md, references/HARNEES_TELAS.md, references/MAPA_FONTES.md, references/PADROES.md, references/SDD_AVANCADO.md, references/SDD_PARA_TELA.md, references/TEMPLATES_PRODUTO.md, references/TIPOGRAFIA.md, references/UX_WRITING.md, references/VISAO_GERAL.md

## v3.4 (2026-06-23)
- Arquivos da skill modificados: 

## v3.3 (2026-06-23)
- Arquivos da skill modificados: README.md
- Decisões de design atualizadas: decisions/CHANGELOG.md
- Outros arquivos: claude/decisions/INDEX.md

## v3.2 (2026-06-15)
- **UX Writing:** `UX_WRITING.md` adicionado como referência de copy e tom de voz (fonte: skill CX Writing v2.0)
- Novo ramo no Fluxo de Decisão para "Criar ou revisar textos de UI"
- Seção 10 adicionada ao `CHECKLIST_REVISAO.md` com 18 itens de revisão de UX Writing
- Regra crítica 5 no `SKILL.md`: consultar `UX_WRITING.md` ao criar qualquer texto na UI
- `VISAO_GERAL.md` atualizado: 15 referências, nova entrada `UX_WRITING.md`, novo bloco de leitura para copy/UX Writing
- Protocolo de triagem obrigatório: componente → contexto → objetivo antes de qualquer copy
- 4 Pilares de Conteúdo como critério de validação (Conciso, Claro, Significativo, Dialógico)
- 12 tipos de texto mapeados com regras DO/DON'T, limites de caracteres e tokens visuais
- Diretrizes B2B (lojista) vs. B2C (consumidor) com linguagem e tom distintos
- Iniciativa de abrasileiramento documentada (sem hífen, termos técnicos contextualizados, sem termos internos externamente)
- Nomenclatura de produtos Olist (primeira menção + menções posteriores)
- Mapeamento SDD → tipo de texto para tradução de requisitos em copy
- `SKILL.md` atualizado para v3.2

## v3.1 (2026-06-05)
- **Harness:** `HARNEES_TELAS.md` adicionado como gate pré-construção obrigatório no fluxo Figma
- Gate com 6 itens binários — o Claude só avança para criação de frames se todos forem marcados
- Restrições de zona por template (ERP e Envios/Hub/Conta Digital): colunas "Pode conter" e "Não pode conter" para cada zona A–E
- Limites quantitativos por componente (ex: máx 1 `Button` primary por tela, máx 1 `Heading` por tela)
- Tabela de contextos válidos e proibidos por componente
- Harness de primitivos: define o que pode ser construído do zero e configuração obrigatória de cada primitivo
- Padrão de nomenclatura de layers obrigatório com formato e exemplos
- Estados mínimos obrigatórios por padrão de página (Tabela, Form, Dashboard, Detalhe, Empty State)
- Regras específicas para skeleton loading
- Formato padronizado para reportar conflitos com o harness (Seção 8)
- `SKILL.md` atualizado para v3.1: harness integrado no fluxo de decisão, tabela de referências e Caso 4

## v3.0 (2026-06-03)
- Remoção do workflow de plugin JSON intermediário — `use_figma` como canal único
- **AI Components** como library master com preferência absoluta sobre ERP components
- `libraryKeys` + `searchPriority` + `blockedLibraries` como fonte da verdade no figma-config.json
- TEMPLATES_PRODUTO.md adicionado (zonas de layout por produto: ERP, Envios, Hub, Conta Digital)
- Regras da Figma Plugin API documentadas (`layoutSizing`, `counterAxisAlignItems`, fonts, etc.)
- Caso de uso 5: componente não existe no inventário → construir com primitivos + documentar
- Caso de uso 6: sincronizar inventário de componentes

## v2.1 (2026-05-07)
- figma-config.example.json na skill (compartilhável)
- FIGMA_CONFIG.md como 12º arquivo de referência
- Instrução para ler figma-config.json antes do Figma MCP
- sync-skill.mjs v2.1
- generate-wiki.mjs criado

## v2.0 (2026-05-04)
- GLOSSARIO_PAPEIS_TEXTO.md (10 papéis de texto)
- SDD_AVANCADO.md (RNFs, DACI, Métricas, Rollout)
- Workflow faseado no Figma
- Sistema de ícones centralizado
- sync-skill.mjs para auto-geração
- validate-icon-migration.mjs

## v1.0
- Versão inicial da skill
- 8 arquivos de referência
