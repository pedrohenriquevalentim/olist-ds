# Decisão Técnica: Convenções de Componentes React

**Categoria:** Técnica
**Status:** Ativa
**Skill de referência:** `.claude/skills/olist-ds-specialist/references/COMPONENTES.md`, `references/MAPA_FONTES.md`

---

## Decisão

Todo componente do design system segue uma estrutura de arquivos padronizada e convenções de código fixas. Desvios geram inconsistência no Storybook e na publicação NPM.

---

## Estrutura de Arquivos Obrigatória

```
src/components/NomeComponente/
  ├── NomeComponente.tsx          # Componente React
  ├── NomeComponente.module.css   # Estilos com CSS Modules
  ├── NomeComponente.test.tsx     # Testes com Vitest + RTL
  ├── NomeComponente.stories.tsx  # Story do Storybook
  └── index.ts                    # Re-export
```

**Antes de criar**, verificar se o componente já existe em `src/components/` e na skill (`references/COMPONENTES.md`).

---

## Convenções de Código

### Declaração
- Arrow functions com export nomeado — nunca default export
- Nomes em PascalCase

```tsx
// ✅ correto
export const Button = ({ label, ...props }: ButtonProps) => { ... }

// ❌ errado
export default function button() { ... }
```

### Props
- Tipadas com `interface` (não `type`) — sempre exportar a interface junto ao componente
- Estender atributos nativos HTML correspondentes
- Boolean props com prefixo `is` / `has`

```tsx
// ✅ correto
export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  hasError?: boolean;
  icon?: React.ReactNode;
}
```

### Variantes e Estados
- Replicar TODAS as variantes visíveis no Figma (tamanho, cor, estado)
- CSS Modules com tokens para cada variante/estado

### Componentes Complexos (Select, Dropdown, Autocomplete)
- Separar Trigger e Popover/List em responsabilidades distintas (funções auxiliares ou sub-componentes no mesmo arquivo)
- Multiselect: usar Generics ou Union Types rigorosos para `value` e `onChange`
- Gerenciar estado interno de visibilidade da lista
- Implementar click-outside para fechar a lista

---

## Testes Obrigatórios (Vitest + RTL)

Cobrir obrigatoriamente:
- Renderização básica
- Variantes principais
- Atributos ARIA
- Injeção correta de `ReactNode` (ícones)

```bash
npm run test:run
```

---

## Storybook (v10)

### Formato obrigatório: CSF3

Toda story usa **Component Story Format 3** — objeto exportado em vez de função, com `satisfies` para inferência de tipo:

```tsx
// ✅ CSF3 correto
import type { Meta, StoryObj } from '@storybook/react';

const meta = {
  title: 'Components/NomeComponente',
  component: NomeComponente,
  parameters: { layout: 'centered' },
} satisfies Meta<typeof NomeComponente>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Padrao: Story = {
  args: { label: 'Exemplo' },
};

// ❌ CSF2 proibido
export const Padrao = () => <NomeComponente label="Exemplo" />;
```

### Dark mode obrigatório

Todo `meta` deve incluir `backgrounds` com as duas opções de tema. Use os valores resolvidos dos tokens semânticos (Storybook não aceita `var(--token)` em `backgrounds.values`):

```tsx
parameters: {
  layout: 'centered',
  backgrounds: {
    default: 'claro',
    values: [
      { name: 'claro', value: '#fcfbf8' }, // --color-background-surface-container light
      { name: 'escuro', value: '#1a1a1a' }, // --color-background-surface-container dark
    ],
  },
},
```

> **Exceção documentada:** `backgrounds.values` é a única permissão de hex resolvido em stories — Storybook não suporta `var()` nesse campo. Nenhum outro uso de valor fixo é permitido.

### Zero hardcode em stories

- Nenhum `style={{ color: '...', fontSize: '...' }}` inline nos decorators ou nos args
- Decorators usam classes CSS ou tokens via `var(--token)` quando precisam de estilo
- Props de ícone: `argTypes` com `mapping` e `control: { type: 'select' }`
- Componentes com opções (Selects): mock robusto de dados na Story
- Todas as descrições e stories em **português**

```bash
npm run storybook
```

---

## Referências na Skill

- API completa dos componentes existentes → `references/COMPONENTES.md`
- Estrutura de pastas do repositório → `references/MAPA_FONTES.md`
- Checklist de revisão de qualidade → `references/CHECKLIST_REVISAO.md`

---

## Documentação no Figma (fluxo unificado)

Ao implementar um componente a partir de URL do Figma, **além dos 5 arquivos de código**, gerar em paralelo o frame `📄 Docs — NomeComponente` na mesma section do componente original.

O frame contém 4 seções obrigatórias: **demo** · **props** · **anatomia** · **acessibilidade**.

Ver `SKILL.md` Caso 7 e `CLAUDE.md` passo 10 para o script completo via `use_figma`.

---

## Histórico

- 2026-09-30 v1.3 — Storybook: CSF3 obrigatório, `backgrounds` claro/escuro obrigatório em todo `meta`, zero hardcode em stories (exceção documentada para `backgrounds.values`).
- 2026-06-25 v1.1 — Adicionada seção sobre geração de docs no Figma (fluxo unificado v3.7)
- 2026-06-23 v1.0 — Decisão inicial extraída do CLAUDE.md
